/*
 * 	startup.c
 *
 */
void startup(void) __attribute__((naked)) __attribute__((section (".start_section")) );
typedef volatile int* port32ptr;
typedef volatile long* port16ptr;
typedef volatile char* port8ptr;
#define GPIO_D_ADDR 0x40020C00
#define GPIO_MODER ((port32ptr)GPIO_D_ADDR)
#define GPIO_OTYPER ((port32ptr)(GPIO_D_ADDR + 0x04))
#define GPIO_OSPEEDR ((port32ptr)(GPIO_D_ADDR + 0x08))
#define GPIO_PUPDR ((port32ptr)(GPIO_D_ADDR + 0x0C))
#define GPIO_IDR_LOW ((port8ptr)(GPIO_D_ADDR + 0x10))
#define GPIO_IDR_HIGH ((port8ptr)(GPIO_D_ADDR + 0x18))
#define GPIO_ODR_LOW ((port8ptr)(GPIO_D_ADDR + 0x14))
#define GPIO_ODR_HIGH ((port8ptr)(GPIO_D_ADDR + 0x1B))



void startup ( void )
{
asm volatile(
	" LDR R0,=0x2001C000\n"		/* set stack */
	" MOV SP,R0\n"
	" BL main\n"				/* call main */
	".L1: B .L1\n"				/* never return */
	) ;
}


void initApp()
{
	*GPIO_MODER = 0x5555;
	*GPIO_MODER &= 0x0000FFFF;
	*GPIO_MODER |= 0x55000000;
	*GPIO_OTYPER &= 0x00FF;
	*GPIO_PUPDR &= 0xFFFF;
	*GPIO_PUPDR |= 0xAA0000;
}


void kbdActivate( unsigned int row )
{
	switch( row )
	{
		case 1: *GPIO_ODR_HIGH = 0x10; break; 
		case 2: *GPIO_ODR_HIGH = 0x20; break; 
		case 3: *GPIO_ODR_HIGH = 0x40; break; 
		case 4: *GPIO_ODR_HIGH = 0x80; break; 
		case 0: *GPIO_ODR_HIGH = 0x00; break;
	}
}

int kbdGetCol ( void )
{
	unsigned char c;
	c = *GPIO_IDR_HIGH;
	if ( c & 0x8 ) return 4; 
	if ( c & 0x4 ) return 3; 
	if ( c & 0x2 ) return 2; 
	if ( c & 0x1 ) return 1;
}

unsigned char keyb(void)
{ 
	int row, col;
	unsigned char key[]={1,2,3,0xA,4,5,6,0xB,7,8,9,0xC,0xE,0,0xF,0xD};
	for (row=1; row <=4 ; row++ ) 
		{
		kbdActivate( row );
		if( (col = kbdGetCol () ) )
			{ 
				kbdActivate( 0 );
			}
		} 
	return key [4*(row-1)+(col-1) ];
	kbdActivate( 0 );
}

void out7seg ( unsigned char c)
{
	switch(c)
	{
		case 0: *GPIO_ODR_LOW = 0x3F; break;
		case 1: *GPIO_ODR_LOW = 0x06; break; 
		case 2: *GPIO_ODR_LOW  = 0x5B; break; 
		case 3: *GPIO_ODR_LOW  = 0x4F; break; 
		case 4: *GPIO_ODR_LOW  = 0x66; break; 
		case 5: *GPIO_ODR_LOW  = 0x6D; break; 
		case 6: *GPIO_ODR_LOW  = 0x7D; break; 
		case 7: *GPIO_ODR_LOW  = 0x07; break; 
		case 8: *GPIO_ODR_LOW  = 0x7F; break; 
		case 9: *GPIO_ODR_LOW  = 0x0F; break; 
		case 10: *GPIO_ODR_LOW  = 0x77; break; 
		case 11: *GPIO_ODR_LOW  = 0x7C; break; 
		case 12: *GPIO_ODR_LOW  = 0x39; break; 
		case 13: *GPIO_ODR_LOW  = 0x5E; break; 
		case 14: *GPIO_ODR_LOW  = 0x79; break; 
		case 15: *GPIO_ODR_LOW  = 0x71; break; 
	}
}
void main(void)
{
	initApp();
	while(1)
	{
		out7seg(keyb());
	}
}


